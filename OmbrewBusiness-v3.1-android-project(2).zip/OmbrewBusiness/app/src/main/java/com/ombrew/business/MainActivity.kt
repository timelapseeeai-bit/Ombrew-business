@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.ombrew.business
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

val Navy=Color(0xFF102B4E);val Brown=Color(0xFF8B5E3C);val Bg=Color(0xFFF4F6F9);val Green=Color(0xFF2E7D32);val Red=Color(0xFFC62828)
val zone:ZoneId=ZoneId.of("Asia/Jakarta")
fun rp(x:Double)="Rp"+NumberFormat.getInstance(Locale("id","ID")).format(Math.round(x))
fun n(s:String)=s.replace(",",".").toDoubleOrNull()?:0.0
fun fmtQ(x:Double)=if(x%1.0==0.0)x.toLong().toString() else "%.1f".format(x)
fun fmt(ts:Long):String=DateTimeFormatter.ofPattern("dd/MM HH:mm").format(Instant.ofEpochMilli(ts).atZone(zone))
fun from(p:String):Long{val t=LocalDate.now(zone);return when(p){"Hari"->t;"Minggu"->t.minusDays(6);"Bulan"->t.withDayOfMonth(1);else->t.withDayOfYear(1)}.atStartOfDay(zone).toInstant().toEpochMilli()}
fun dayMs(d:LocalDate)=d.atStartOfDay(zone).toInstant().toEpochMilli()
fun money0(x:Double)=if(x==0.0)"" else x.toLong().toString()
data class St(val sales:Double,val trx:Int,val hpp:Double,val biaya:Double,val buang:Double){val gross get()=sales-hpp;val net get()=gross-biaya-buang}
fun stat(s:List<Sale>,c:List<CashTx>,m:List<StockMove>,f:Long,to:Long=Long.MAX_VALUE):St{val o=s.filter{it.status=="OK"&&it.ts in f until to}
 return St(o.sumOf{it.total},o.size,o.sumOf{it.hpp},-c.filter{it.type=="BIAYA"&&it.ts in f until to}.sumOf{it.amount},m.filter{it.type=="BUANG"&&it.ts in f until to}.sumOf{it.value})}

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b)
 WindowCompat.setDecorFitsSystemWindows(window,false);window.statusBarColor=android.graphics.Color.TRANSPARENT;window.navigationBarColor=Navy.toArgb()
 setContent{MaterialTheme(colorScheme=lightColorScheme(primary=Navy,secondary=Brown,background=Bg)){Root()}}}}

class RpFmt:VisualTransformation{override fun filter(text:AnnotatedString):TransformedText{
 val s=text.text;val L=s.length;val sb=StringBuilder();val o2t=IntArray(L+1)
 for(i in 0 until L){if(i>0&&(L-i)%3==0)sb.append('.');o2t[i]=sb.length;sb.append(s[i])};o2t[L]=sb.length
 return TransformedText(AnnotatedString(sb.toString()),object:OffsetMapping{
  override fun originalToTransformed(offset:Int)=o2t[offset.coerceIn(0,L)]
  override fun transformedToOriginal(offset:Int)=(0 until L).count{o2t[it]<offset}})}}

@Composable fun Page(c:@Composable ColumnScope.()->Unit)=Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(12.dp),content=c)
@Composable fun Box2(mod:Modifier=Modifier.fillMaxWidth(),c:@Composable ColumnScope.()->Unit)=Card(mod.padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp),content=c)}
@Composable fun Stat(l:String,v:String,col:Color=Navy,mod:Modifier=Modifier.fillMaxWidth())=Box2(mod){Text(l,fontSize=12.sp);Text(v,fontSize=18.sp,fontWeight=FontWeight.Bold,color=col)}
@Composable fun Two(a:@Composable RowScope.()->Unit)=Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),content=a)
@Composable fun <T> Pick(items:List<T>,sel:T?,name:(T)->String,on:(T)->Unit){Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){items.forEach{FilterChip(selected=it==sel,onClick={on(it)},label={Text(name(it))})}}}
@Composable fun Fld(l:String,v:String,on:(String)->Unit,num:Boolean=false)=OutlinedTextField(v,on,label={Text(l)},singleLine=true,modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(keyboardType=if(num)KeyboardType.Decimal else KeyboardType.Text))
@Composable fun Money(l:String,v:String,on:(String)->Unit)=OutlinedTextField(v,{on(it.filter(Char::isDigit))},label={Text(l)},prefix={Text("Rp ")},singleLine=true,modifier=Modifier.fillMaxWidth(),visualTransformation=RpFmt(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
@Composable fun Btn(t:String,on:()->Unit)=Button(on,Modifier.fillMaxWidth()){Text(t)}
@Composable fun H(t:String)=Text(t,fontWeight=FontWeight.Bold,color=Navy)
@Composable fun Bars(title:String,v:List<Double>,lab:List<String>,col:Color)=Box2{H(title);val mx=(v.maxOrNull()?:0.0).coerceAtLeast(1.0)
 Row(Modifier.fillMaxWidth().height(120.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.Bottom){v.forEachIndexed{i,x->Column(horizontalAlignment=Alignment.CenterHorizontally){
  Box(Modifier.width(28.dp).height((90*(maxOf(x,0.0)/mx)).dp.coerceAtLeast(2.dp)).background(col,RoundedCornerShape(4.dp)));Text(lab[i],fontSize=10.sp)}}}}
@Composable fun Photo(path:String,mod:Modifier){
 if(path=="res:menu_default")Image(painterResource(R.drawable.menu_default),null,mod,contentScale=ContentScale.Crop)
 else{val bmp=remember(path){if(path.isBlank())null else BitmapFactory.decodeFile(path,BitmapFactory.Options().apply{inSampleSize=2})?.asImageBitmap()}
  if(bmp!=null)Image(bmp,null,mod,contentScale=ContentScale.Crop) else Box(mod.background(Color(0xFFE3E8F0)),contentAlignment=Alignment.Center){Icon(Icons.Outlined.LocalCafe,null,tint=Navy)}}}
@Composable fun Grid(items:List<Product>,sel:Long?,on:(Product)->Unit){items.chunked(2).forEach{row->
 Row(Modifier.fillMaxWidth().padding(vertical=4.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
  row.forEach{p->Card(Modifier.weight(1f).clickable{on(p)},border=if(p.id==sel)BorderStroke(2.dp,Brown) else null,colors=CardDefaults.cardColors(containerColor=Color.White)){
   Column{Photo(p.photo,Modifier.fillMaxWidth().height(96.dp));Column(Modifier.padding(8.dp)){Text(p.name+if(p.active)"" else " (nonaktif)",fontWeight=FontWeight.Bold,maxLines=1);Text(rp(p.price),fontSize=12.sp,color=Brown)}}}}
  if(row.size==1)Spacer(Modifier.weight(1f))}}}

class Tab(val name:String,val icon:ImageVector)
val tabs=listOf(Tab("Beranda",Icons.Outlined.Dashboard),Tab("Penjualan",Icons.Outlined.ShoppingCart),Tab("Produk",Icons.Outlined.LocalCafe),Tab("Persediaan",Icons.Outlined.Inventory2),Tab("Pembelian",Icons.Outlined.AddBox),Tab("Keuangan",Icons.Outlined.AccountBalanceWallet),Tab("Laporan",Icons.Outlined.BarChart),Tab("Pengaturan",Icons.Outlined.Settings))

@Composable fun Root(){
 val vm:VM=viewModel();val ctx=LocalContext.current;val pr=ctx.getSharedPreferences("o",0)
 var splash by rememberSaveable{mutableStateOf(true)}
 LaunchedEffect(Unit){delay(1400);splash=false}
 if(splash){Column(Modifier.fillMaxSize().background(Color.White).padding(40.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
  Image(painterResource(R.drawable.logo_navy),"Ombrew",Modifier.fillMaxWidth(0.8f));Spacer(Modifier.height(16.dp));Text("Manage Your Business, Grow Your Coffee.",color=Brown,fontSize=13.sp)};return}
 var unlocked by rememberSaveable{mutableStateOf(pr.getString("pin","")=="")}
 if(!unlocked){PinScr(pr.getString("pin","")!!){unlocked=true};return}
 var tab by rememberSaveable{mutableStateOf(0)};var csvFrom by rememberSaveable{mutableStateOf(0L)};var photoPid by rememberSaveable{mutableStateOf(0L)}
 val snack=remember{SnackbarHostState()};val holder=rememberSaveableStateHolder()
 val conf=remember{mutableStateOf<Pair<String,()->Unit>?>(null)};val ask:(String,()->Unit)->Unit={t,a->conf.value=t to a}
 LaunchedEffect(Unit){vm.msg.collect{snack.showSnackbar(it)}}
 val exp=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){u->u?.let{vm.backup(ctx,it)}}
 val imp=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{vm.restore(ctx,it)}}
 val csv=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){u->u?.let{vm.csv(ctx,it,csvFrom)}}
 val pic=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u->u?.let{vm.setPhoto(ctx,photoPid,it)}}
 conf.value?.let{(t,a)->AlertDialog(onDismissRequest={conf.value=null},title={Text("Konfirmasi")},text={Text(t)},confirmButton={TextButton({a();conf.value=null}){Text("Ya")}},dismissButton={TextButton({conf.value=null}){Text("Tidak")}})}
 Scaffold(snackbarHost={SnackbarHost(snack)},
  topBar={Row(Modifier.fillMaxWidth().background(Navy).statusBarsPadding().padding(horizontal=16.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
   Image(painterResource(R.drawable.logo_white),"Ombrew",Modifier.height(24.dp));Spacer(Modifier.weight(1f));Text(tabs[tab].name,color=Color.White)}},
  bottomBar={Row(Modifier.fillMaxWidth().background(Navy).navigationBarsPadding().horizontalScroll(rememberScrollState())){
   tabs.forEachIndexed{i,t->val c=if(i==tab)Color.White else Color(0xFF8FA3BF)
    Column(Modifier.clickable{tab=i}.padding(horizontal=14.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(t.icon,null,tint=c);Text(t.name,fontSize=11.sp,color=c)}}}}
 ){pad->Box(Modifier.padding(pad).imePadding()){holder.SaveableStateProvider(tab){when(tab){
  0->Home(vm);1->SalesScr(vm,ask);2->ProdScr(vm,ask){photoPid=it;pic.launch("image/*")};3->StockScr(vm);4->BuyScr(vm);5->FinScr(vm)
  6->ReportScr(vm){csvFrom=it;csv.launch("laporan.csv")}
  else->SetScr(vm,ask,{exp.launch("ombrew-backup.json")},{imp.launch(arrayOf("*/*"))})}}}}
}
@Composable fun PinScr(pin:String,ok:()->Unit){var v by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().background(Navy).padding(32.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
  Image(painterResource(R.drawable.logo_white),"Ombrew",Modifier.fillMaxWidth(0.7f));Spacer(Modifier.height(24.dp))
  Card{OutlinedTextField(v,{v=it;if(it==pin)ok()},label={Text("PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),modifier=Modifier.fillMaxWidth())}}}

@Composable fun Home(vm:VM){
 val sales by vm.sales.collectAsState();val cash by vm.cash.collectAsState();val moves by vm.moves.collectAsState();val ings by vm.ings.collectAsState()
 val pr=LocalContext.current.getSharedPreferences("o",0);val t=stat(sales,cash,moves,from("Hari"))
 val days=(6 downTo 0).map{LocalDate.now(zone).minusDays(it.toLong())};val ds=days.map{stat(sales,cash,moves,dayMs(it),dayMs(it.plusDays(1)))};val lab=days.map{"${it.dayOfMonth}/${it.monthValue}"}
 Page{Box2{Image(painterResource(R.drawable.logo_navy),"Ombrew",Modifier.fillMaxWidth(0.6f).align(Alignment.CenterHorizontally))}
  Two{Stat("Penjualan hari ini",rp(t.sales),mod=Modifier.weight(1f));Stat("Transaksi",t.trx.toString(),mod=Modifier.weight(1f))}
  Two{Stat("HPP",rp(t.hpp),mod=Modifier.weight(1f));Stat("Laba kotor",rp(t.gross),if(t.gross>=0)Green else Red,Modifier.weight(1f))}
  Two{Stat("Pengeluaran",rp(t.biaya+t.buang),mod=Modifier.weight(1f));Stat("Laba bersih",rp(t.net),if(t.net>=0)Green else Red,Modifier.weight(1f))}
  Stat("Saldo kas usaha",rp(cash.sumOf{it.amount}))
  val tg=pr.getFloat("target",0f).toDouble();if(tg>0)Box2{Text("Target harian ${rp(tg)}: ${(t.sales/tg*100).toInt()}% tercapai");LinearProgressIndicator(progress={(t.sales/tg).toFloat().coerceIn(0f,1f)},Modifier.fillMaxWidth())}
  val low=ings.filter{it.minStock>0&&it.stock<=it.minStock}
  if(low.isNotEmpty())Box2{Text("Stok menipis",color=Red,fontWeight=FontWeight.Bold);low.forEach{Text("${it.name}: ${fmtQ(it.stock)} ${it.unit}")}}
  Bars("Penjualan 7 hari",ds.map{it.sales},lab,Navy);Bars("Laba kotor 7 hari",ds.map{it.gross},lab,Green)
  Box2{H("Ringkasan performa");Text(if(t.sales>0)"Margin kotor hari ini ${"%.1f".format(t.gross/t.sales*100)}%, rata-rata ${rp(t.sales/maxOf(t.trx,1))} per transaksi." else "Belum ada penjualan hari ini.")}
  Box2{H("Produk terlaris");sales.filter{it.status=="OK"}.groupBy{it.productName}.mapValues{e->e.value.sumOf{s->s.qty}}.entries.sortedByDescending{it.value}.take(3).forEach{Text("${it.key} – ${it.value} terjual")}}
  Box2{H("Transaksi terbaru");sales.take(5).forEach{Text("${fmt(it.ts)} ${it.productName} x${it.qty} ${rp(it.total)}${if(it.status!="OK")" (batal)" else ""}")}}}}

@Composable fun SaleRow(s:Sale,open:Boolean,tog:()->Unit,vm:VM,ask:(String,()->Unit)->Unit){
 val col=if(s.status!="OK")Color.Gray else if(!s.paid)Brown else Green
 Card(Modifier.fillMaxWidth().padding(vertical=3.dp).clickable(onClick=tog),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){
  Row{Column(Modifier.weight(1f)){Text("${s.productName} ×${s.qty}",fontWeight=FontWeight.Bold);Text(fmt(s.ts),fontSize=12.sp)}
   Column(horizontalAlignment=Alignment.End){Text(rp(s.total),fontWeight=FontWeight.Bold);Text(if(s.status!="OK")"Batal" else if(!s.paid)"Piutang" else s.payment,fontSize=12.sp,color=col)}}
  if(open){Spacer(Modifier.height(6.dp));Text("HPP ${rp(s.hpp)} • Laba ${rp(s.total-s.hpp)}\n${s.channel} • ${s.payment}",fontSize=13.sp)
   if(s.status=="OK")Row(Modifier.padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
    if(!s.paid)OutlinedButton({vm.collect(s.id)}){Text("Terima piutang")}
    OutlinedButton({ask("Batalkan transaksi ${s.productName} ×${s.qty}? Stok dan kas akan dikembalikan."){vm.void(s.id)}},colors=ButtonDefaults.outlinedButtonColors(contentColor=Red)){Text("Batalkan")}}}}}}

@Composable fun SalesScr(vm:VM,ask:(String,()->Unit)->Unit){
 val prods by vm.prods.collectAsState();val sales by vm.sales.collectAsState()
 var pid by rememberSaveable{mutableStateOf<Long?>(null)};var qs by rememberSaveable{mutableStateOf("")};var q by rememberSaveable{mutableStateOf("1")};var dc by rememberSaveable{mutableStateOf("")}
 var ch by rememberSaveable{mutableStateOf("Langsung")};var pay by rememberSaveable{mutableStateOf("Tunai")};var open by rememberSaveable{mutableStateOf(0L)}
 val p=prods.find{it.id==pid};val total=(p?.price?:0.0)*(q.toIntOrNull()?:0)-n(dc)
 Page{Box2{H("Catat penjualan");Fld("Cari produk",qs,{qs=it})
   Grid(prods.filter{it.active&&it.name.contains(qs,true)},pid){pid=it.id}
   if(p!=null){Text("${p.name} • total ${rp(total)}",fontWeight=FontWeight.Bold,color=Brown)}
   Fld("Jumlah",q,{q=it.filter(Char::isDigit)});Money("Diskon",dc){dc=it};Pick(listOf("Langsung","Online"),ch,{it}){ch=it};Pick(listOf("Tunai","Transfer","QRIS","Piutang"),pay,{it}){pay=it}
   Btn("Simpan penjualan"){p?.let{vm.sell(it,q.toIntOrNull()?:0,n(dc),ch,pay)}}}
  H("Riwayat transaksi");sales.take(50).forEach{s->SaleRow(s,open==s.id,{open=if(open==s.id)0L else s.id},vm,ask)}}}

@Composable fun ProdScr(vm:VM,ask:(String,()->Unit)->Unit,onPhoto:(Long)->Unit){
 val prods by vm.prods.collectAsState();val rec by vm.recipes.collectAsState();val ings by vm.ings.collectAsState()
 var pid by rememberSaveable{mutableStateOf<Long?>(null)};var nm by rememberSaveable{mutableStateOf("")};val p=prods.find{it.id==pid}
 Page{Box2{Fld("Nama produk baru",nm,{nm=it});Btn("Tambah produk"){vm.addProd(nm);nm=""}}
  Grid(prods,pid){pid=it.id}
  p?.let{ProdEdit(vm,it,rec.filter{r->r.productId==it.id},ings,ask,onPhoto)}}}
@Composable fun ProdEdit(vm:VM,p:Product,rec:List<RecipeItem>,ings:List<Ingredient>,ask:(String,()->Unit)->Unit,onPhoto:(Long)->Unit){key(p.id){
 var nm by rememberSaveable{mutableStateOf(p.name)};var pr by rememberSaveable{mutableStateOf(money0(p.price))};var mh by rememberSaveable{mutableStateOf(money0(p.manualHpp))}
 var y by rememberSaveable{mutableStateOf(p.yieldQty.toString())};var use by rememberSaveable{mutableStateOf(p.useRecipe)};var act by rememberSaveable{mutableStateOf(p.active)}
 var iid by rememberSaveable{mutableStateOf<Long?>(null)};var q by rememberSaveable{mutableStateOf("")};var u by rememberSaveable{mutableStateOf("g")}
 val yy=(y.toIntOrNull()?:1).coerceAtLeast(1);val pv=n(pr)
 val h=if(use)rec.sumOf{r->r.qty*(ings.find{it.id==r.ingredientId}?.avgCost?:0.0)}/yy else n(mh)
 Box2{Photo(p.photo,Modifier.fillMaxWidth().height(180.dp));OutlinedButton({onPhoto(p.id)},Modifier.fillMaxWidth()){Text("Pasang / ganti foto produk")}
  Fld("Nama",nm,{nm=it});Money("Harga jual",pr){pr=it}
  Row(verticalAlignment=Alignment.CenterVertically){Switch(use,{use=it});Text(" HPP dari resep (mati = HPP manual)")}
  if(use)Fld("Hasil resep (botol)",y,{y=it.filter(Char::isDigit)}) else Money("HPP manual per produk",mh){mh=it}
  Row(verticalAlignment=Alignment.CenterVertically){Switch(act,{act=it});Text(" Aktif")}
  Text("HPP ${rp(h)} • Laba kotor ${rp(pv-h)} • Margin ${if(pv>0)"%.1f".format((pv-h)/pv*100) else "0"}%")
  Text("Rekomendasi harga: "+listOf(0.3,0.4,0.5).joinToString{"${(it*100).toInt()}% → ${rp(h/(1-it))}"})
  Btn("Simpan"){vm.saveProd(p.copy(name=nm,price=pv,manualHpp=n(mh),yieldQty=yy,useRecipe=use,active=act))}
  TextButton({ask("Hapus produk ${p.name}? Hanya bisa jika belum punya transaksi."){vm.delProd(p.id)}}){Text("Hapus produk",color=Red)}}
 if(use)Box2{H("Resep (untuk $yy botol)")
  rec.forEach{r->val i=ings.find{it.id==r.ingredientId};Row(verticalAlignment=Alignment.CenterVertically){Text("${i?.name} ${fmtQ(r.qty)} ${i?.unit}",Modifier.weight(1f));TextButton({vm.delRec(r.id)}){Text("Hapus")}}}
  Pick(ings,ings.find{it.id==iid},{it.name}){iid=it.id;u=it.unit};Pick(units,u,{it}){u=it};Fld("Takaran",q,{q=it},true)
  Btn("Tambah ke resep"){ings.find{it.id==iid}?.let{vm.addRec(p.id,it,n(q),u)}}}}}

@Composable fun StockScr(vm:VM){
 val ings by vm.ings.collectAsState();val moves by vm.moves.collectAsState()
 var nm by rememberSaveable{mutableStateOf("")};var bu by rememberSaveable{mutableStateOf("g")};var mn by rememberSaveable{mutableStateOf("")}
 var iid by rememberSaveable{mutableStateOf<Long?>(null)};var q by rememberSaveable{mutableStateOf("")};var u by rememberSaveable{mutableStateOf("g")};var mode by rememberSaveable{mutableStateOf("Koreksi")}
 val cur=ings.find{it.id==iid}
 Page{Box2{H("Bahan baru");Fld("Nama",nm,{nm=it});Pick(listOf("g","ml","pcs"),bu,{it}){bu=it};Fld("Batas minimum ($bu)",mn,{mn=it},true);Btn("Tambah bahan"){vm.addIng(nm,bu,n(mn));nm=""}}
  H("Nilai persediaan: ${rp(ings.sumOf{it.stock*it.avgCost})}")
  ings.forEach{Box2{Text(it.name,fontWeight=FontWeight.Bold);Text("Stok ${fmtQ(it.stock)} ${it.unit} • rata-rata ${rp(it.avgCost)}/${it.unit}",color=if(it.minStock>0&&it.stock<=it.minStock)Red else Color.Unspecified)}}
  Box2{H("Koreksi stok / catat limbah");Pick(ings,cur,{it.name}){iid=it.id;u=it.unit};Pick(listOf("Koreksi","Rusak","Kedaluwarsa","Terbuang","Gagal produksi"),mode,{it}){mode=it};Pick(units,u,{it}){u=it}
   Fld(if(mode=="Koreksi")"Stok baru" else "Jumlah dibuang",q,{q=it},true);Btn("Simpan"){cur?.let{vm.stockOp(it,n(q),u,mode)}}}
  H("Riwayat stok");moves.take(20).forEach{m->Text("${fmt(m.ts)} ${ings.find{i->i.id==m.ingredientId}?.name} ${fmtQ(m.delta)} ${m.type}")}}}

@Composable fun BuyScr(vm:VM){
 val ings by vm.ings.collectAsState();val moves by vm.moves.collectAsState()
 var iid by rememberSaveable{mutableStateOf<Long?>(null)};var q by rememberSaveable{mutableStateOf("")};var u by rememberSaveable{mutableStateOf("g")}
 var tot by rememberSaveable{mutableStateOf("")};var sup by rememberSaveable{mutableStateOf("")};var note by rememberSaveable{mutableStateOf("")}
 Page{Box2{H("Pembelian bahan baku");Pick(ings,ings.find{it.id==iid},{it.name}){iid=it.id;u=it.unit};Fld("Jumlah",q,{q=it},true);Pick(units,u,{it}){u=it}
   Money("Total harga beli",tot){tot=it};Fld("Pemasok",sup,{sup=it});Fld("Catatan",note,{note=it})
   Btn("Simpan pembelian"){ings.find{it.id==iid}?.let{vm.buy(it,n(q),u,n(tot),sup,note)}}}
  H("Riwayat pembelian");moves.filter{it.type=="BELI"}.take(30).forEach{m->Text("${fmt(m.ts)} ${ings.find{i->i.id==m.ingredientId}?.name} +${fmtQ(m.delta)} ${rp(m.value)} ${m.note}")}}}

@Composable fun FinScr(vm:VM){
 val cash by vm.cash.collectAsState();var t by rememberSaveable{mutableStateOf("Biaya")};var a by rememberSaveable{mutableStateOf("")};var note by rememberSaveable{mutableStateOf("")}
 fun s(vararg k:String)=cash.filter{it.type in k}.sumOf{it.amount}
 Page{Stat("Saldo kas usaha",rp(cash.sumOf{it.amount}))
  Two{Stat("Modal",rp(s("MODAL")),mod=Modifier.weight(1f));Stat("Pemasukan",rp(s("PENJUALAN","PIUTANG","BATAL")),Green,Modifier.weight(1f))}
  Two{Stat("Beli stok",rp(-s("BELI")),mod=Modifier.weight(1f));Stat("Operasional",rp(-s("BIAYA")),Red,Modifier.weight(1f))}
  Stat("Prive",rp(-s("PRIVE")))
  Box2{Pick(listOf("Modal","Biaya","Prive"),t,{it}){t=it};Money("Jumlah",a){a=it};Fld("Catatan",note,{note=it});Btn("Simpan"){vm.cashOp(t.uppercase(),n(a),note)}}
  H("Arus kas");cash.take(40).forEach{Text("${fmt(it.ts)} ${it.type} ${rp(it.amount)} ${it.note}",color=if(it.amount>=0)Green else Red)}}}

@Composable fun ReportScr(vm:VM,onCsv:(Long)->Unit){
 val sales by vm.sales.collectAsState();val cash by vm.cash.collectAsState();val moves by vm.moves.collectAsState()
 var per by rememberSaveable{mutableStateOf("Hari")};val f=from(per);val t=stat(sales,cash,moves,f)
 Page{Pick(listOf("Hari","Minggu","Bulan","Tahun"),per,{it}){per=it}
  Two{Stat("Penjualan",rp(t.sales),mod=Modifier.weight(1f));Stat("Transaksi",t.trx.toString(),mod=Modifier.weight(1f))}
  Two{Stat("HPP",rp(t.hpp),mod=Modifier.weight(1f));Stat("Laba kotor",rp(t.gross),mod=Modifier.weight(1f))}
  Two{Stat("Biaya operasional",rp(t.biaya),mod=Modifier.weight(1f));Stat("Kerugian limbah",rp(t.buang),Red,Modifier.weight(1f))}
  Stat("Keuntungan bersih",rp(t.net),if(t.net>=0)Green else Red)
  val ok=sales.filter{it.status=="OK"&&it.ts>=f}
  Box2{H("Produk terlaris");ok.groupBy{it.productName}.mapValues{e->e.value.sumOf{s->s.qty}}.entries.sortedByDescending{it.value}.take(5).forEach{Text("${it.key} – ${it.value}")}}
  Box2{H("Laba tertinggi");ok.groupBy{it.productName}.mapValues{e->e.value.sumOf{s->s.total-s.hpp}}.entries.sortedByDescending{it.value}.take(5).forEach{Text("${it.key} – ${rp(it.value)}")}}
  Box2{Text("Pergerakan stok: ${moves.count{it.ts>=f}} catatan")}
  Btn("Unduh CSV"){onCsv(f)}}}

@Composable fun SetScr(vm:VM,ask:(String,()->Unit)->Unit,onBackup:()->Unit,onRestore:()->Unit){
 val pr=LocalContext.current.getSharedPreferences("o",0)
 var pin by rememberSaveable{mutableStateOf(pr.getString("pin","")!!)};var tg by rememberSaveable{mutableStateOf(money0(pr.getFloat("target",0f).toDouble()))}
 Page{Box2{H("Keamanan");Fld("PIN (kosong = tanpa PIN)",pin,{pin=it.filter(Char::isDigit)});Btn("Simpan PIN"){pr.edit().putString("pin",pin).apply()}}
  Box2{H("Target penjualan harian");Money("Target",tg){tg=it};Btn("Simpan target"){pr.edit().putFloat("target",n(tg).toFloat()).apply()}}
  Box2{H("Backup & restore (JSON)");Btn("Backup sekarang",onBackup);Btn("Restore dari file"){ask("Restore akan menimpa seluruh data saat ini. Lanjutkan?",onRestore)};Text("Foto produk tidak ikut dalam file backup.",fontSize=12.sp)}
  Text("Ombrew Business V3.0 – Navy Edition\nManage Your Business, Grow Your Coffee.")}}
