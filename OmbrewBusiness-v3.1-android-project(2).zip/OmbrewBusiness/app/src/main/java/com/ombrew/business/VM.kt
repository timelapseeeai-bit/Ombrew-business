package com.ombrew.business
import android.app.Application
import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import androidx.room.withTransaction
import com.google.gson.Gson
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class Bk(val i:List<Ingredient>,val p:List<Product>,val r:List<RecipeItem>,val s:List<Sale>,val m:List<StockMove>,val c:List<CashTx>)
fun base(u:String)=when(u){"g","kg"->"g";"ml","l"->"ml";else->"pcs"}
fun fac(u:String)=if(u=="kg"||u=="l")1000.0 else 1.0
val units=listOf("g","kg","ml","l","pcs","botol","cup")

class VM(a:Application):AndroidViewModel(a){
 val db=Room.databaseBuilder(a,DB::class.java,"ombrew.db").build()
 val d=db.d()
 private fun <T> st(f:Flow<List<T>>)=f.stateIn(viewModelScope,SharingStarted.Eagerly,emptyList())
 val ings=st(d.ings());val prods=st(d.prods());val recipes=st(d.recipes());val sales=st(d.sales());val moves=st(d.moves());val cash=st(d.cash())
 val msg=MutableSharedFlow<String>(extraBufferCapacity=4)
 private var busy=false
 private fun now()=System.currentTimeMillis()
 init{viewModelScope.launch{if(d.nProd()==0)seed()}}
 fun go(b:suspend()->String?){ if(busy)return; busy=true
  viewModelScope.launch{try{msg.tryEmit(b()?:"Tersimpan")}catch(e:Exception){msg.tryEmit("Gagal: ${e.message}")}finally{busy=false}}}
 private suspend fun seed(){
  val ids=listOf("Susu UHT" to "ml","Susu evaporasi" to "ml","Gula aren bubuk" to "g","Nescafe" to "g","Air panas" to "ml").map{d.put(Ingredient(name=it.first,unit=it.second))}
  val p=d.put(Product(name="Kopi Susu Gula Aren",yieldQty=8,photo="res:menu_default"))
  ids.zip(listOf(1000.0,500.0,150.0,25.0,500.0)).forEach{d.put(RecipeItem(productId=p,ingredientId=it.first,qty=it.second))}
  listOf("Palm Sugar","Spanish Latte","Caffè Latte","Butterscotch","Americano").forEach{d.put(Product(name=it,useRecipe=false))}
 }
 fun addProd(n:String)=go{if(n.isBlank())"Nama kosong" else {d.put(Product(name=n.trim()));null}}
 fun saveProd(p:Product)=go{if(p.name.isBlank()||p.price<0)"Input tidak valid" else {d.put(p);null}}
 fun delProd(id:Long)=go{db.withTransaction{if(d.salesCount(id)>0)"Produk punya riwayat transaksi, nonaktifkan saja" else {d.delRecOf(id);d.delProd(id);null}}}
 fun setPhoto(c:Context,pid:Long,u:Uri)=go{withContext(Dispatchers.IO){
  val bmp=c.contentResolver.openInputStream(u)!!.use{BitmapFactory.decodeStream(it,null,BitmapFactory.Options().apply{inSampleSize=3})}!!
  val f=File(c.filesDir,"p_${pid}_${now()}.jpg");f.outputStream().use{bmp.compress(Bitmap.CompressFormat.JPEG,85,it)}
  d.prod(pid)?.let{d.put(it.copy(photo=f.absolutePath))}};"Foto dipasang"}
 fun addRec(pid:Long,i:Ingredient,q:Double,u:String)=go{
  if(q<=0)"Takaran tidak valid" else if(base(u)!=i.unit)"Satuan tidak cocok (${i.name} dalam ${i.unit})" else {d.put(RecipeItem(productId=pid,ingredientId=i.id,qty=q*fac(u)));null}}
 fun delRec(id:Long)=go{d.delRec(id);null}
 fun addIng(n:String,u:String,min:Double)=go{if(n.isBlank())"Nama kosong" else {d.put(Ingredient(name=n.trim(),unit=u,minStock=min));null}}
 fun stockOp(i:Ingredient,q:Double,u:String,mode:String)=go{db.withTransaction{
  if(base(u)!=i.unit)return@withTransaction "Satuan tidak cocok (${i.unit})"
  val qb=q*fac(u)
  if(mode=="Koreksi"){ val delta=qb-i.stock
   d.put(i.copy(stock=qb));d.put(StockMove(ts=now(),ingredientId=i.id,delta=delta,type="KOREKSI",value=Math.abs(delta)*i.avgCost)) }
  else { if(qb<=0||qb>i.stock+1e-9)return@withTransaction "Jumlah melebihi stok"
   d.put(i.copy(stock=i.stock-qb));d.put(StockMove(ts=now(),ingredientId=i.id,delta=-qb,type="BUANG",value=qb*i.avgCost,note=mode)) }
  null}}
 fun buy(i:Ingredient,q:Double,u:String,total:Double,sup:String,note:String)=go{db.withTransaction{
  if(base(u)!=i.unit)return@withTransaction "Satuan tidak cocok (${i.unit})"
  val qb=q*fac(u); if(qb<=0||total<0)return@withTransaction "Input tidak valid"
  val avg=(i.stock*i.avgCost+total)/(i.stock+qb)
  d.put(i.copy(stock=i.stock+qb,avgCost=avg))
  d.put(StockMove(ts=now(),ingredientId=i.id,delta=qb,type="BELI",value=total,note="$sup $note".trim()))
  d.put(CashTx(ts=now(),type="BELI",amount=-total,note="${i.name} $sup".trim()))
  null}}
 fun cashOp(type:String,a:Double,note:String)=go{if(a<=0)"Jumlah tidak valid" else {d.put(CashTx(ts=now(),type=type,amount=if(type=="MODAL")a else -a,note=note));null}}
 fun sell(p:Product,qty:Int,disc:Double,ch:String,pay:String)=go{db.withTransaction{
  if(qty<=0)return@withTransaction "Jumlah tidak valid"
  val total=p.price*qty-disc; if(total<0||disc<0)return@withTransaction "Diskon tidak valid"
  val use=(if(p.useRecipe)d.recipe(p.id) else emptyList()).map{Pair(d.ing(it.ingredientId)!!,it.qty*qty/p.yieldQty)}
  use.firstOrNull{it.first.stock<it.second-1e-9}?.let{return@withTransaction "Stok ${it.first.name} tidak cukup"}
  val hpp=if(p.useRecipe)use.sumOf{it.first.avgCost*it.second} else p.manualHpp*qty
  val t=now()
  val id=d.put(Sale(ts=t,productId=p.id,productName=p.name,qty=qty,price=p.price,discount=disc,total=total,hpp=hpp,channel=ch,payment=pay,paid=pay!="Piutang"))
  use.forEach{(i,q)->d.put(i.copy(stock=i.stock-q));d.put(StockMove(ts=t,ingredientId=i.id,delta=-q,type="JUAL",value=i.avgCost*q,ref=id))}
  if(pay!="Piutang")d.put(CashTx(ts=t,type="PENJUALAN",amount=total,note=p.name,ref=id))
  null}}
 fun void(id:Long)=go{db.withTransaction{
  val s=d.sale(id)?:return@withTransaction "Tidak ditemukan"
  if(s.status!="OK")return@withTransaction "Sudah dibatalkan"
  val t=now()
  d.movesOf(id).forEach{m->val i=d.ing(m.ingredientId)!!;d.put(i.copy(stock=i.stock-m.delta));d.put(StockMove(ts=t,ingredientId=i.id,delta=-m.delta,type="BATAL",value=m.value,ref=id))}
  if(s.paid)d.put(CashTx(ts=t,type="BATAL",amount=-s.total,note=s.productName,ref=id))
  d.put(s.copy(status="VOID"));null}}
 fun collect(id:Long)=go{db.withTransaction{
  val s=d.sale(id)?:return@withTransaction "Tidak ditemukan"
  if(s.paid||s.status!="OK")return@withTransaction "Tidak ada piutang"
  d.put(s.copy(paid=true));d.put(CashTx(ts=now(),type="PIUTANG",amount=s.total,note=s.productName,ref=id));null}}
 fun backup(c:Context,u:Uri)=go{withContext(Dispatchers.IO){
  val b=Bk(ings.value,prods.value,recipes.value,sales.value,moves.value,cash.value)
  c.contentResolver.openOutputStream(u)!!.use{it.write(Gson().toJson(b).toByteArray())}};"Backup selesai"}
 fun restore(c:Context,u:Uri)=go{withContext(Dispatchers.IO){
  val b=Gson().fromJson(c.contentResolver.openInputStream(u)!!.bufferedReader().readText(),Bk::class.java)
  db.clearAllTables()
  db.withTransaction{b.i.forEach{d.put(it)};b.p.forEach{d.put(it)};b.r.forEach{d.put(it)};b.s.forEach{d.put(it)};b.m.forEach{d.put(it)};b.c.forEach{d.put(it)}}};"Restore selesai"}
 fun csv(c:Context,u:Uri,f:Long)=go{withContext(Dispatchers.IO){
  val sb=StringBuilder("tanggal,produk,jumlah,diskon,total,hpp,laba,saluran,pembayaran,status\n")
  sales.value.filter{it.ts>=f}.forEach{sb.append("${fmt(it.ts)},\"${it.productName}\",${it.qty},${it.discount},${it.total},${it.hpp},${it.total-it.hpp},${it.channel},${it.payment},${it.status}\n")}
  c.contentResolver.openOutputStream(u)!!.use{it.write(sb.toString().toByteArray())}};"CSV tersimpan"}
}
