package com.ombrew.business
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Ingredient(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val unit:String,val stock:Double=0.0,val avgCost:Double=0.0,val minStock:Double=0.0)
@Entity data class Product(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val price:Double=0.0,val active:Boolean=true,val useRecipe:Boolean=true,val manualHpp:Double=0.0,val yieldQty:Int=1,val photo:String="")
@Entity data class RecipeItem(@PrimaryKey(autoGenerate=true) val id:Long=0,val productId:Long,val ingredientId:Long,val qty:Double)
@Entity data class Sale(@PrimaryKey(autoGenerate=true) val id:Long=0,val ts:Long,val productId:Long,val productName:String,val qty:Int,val price:Double,val discount:Double,val total:Double,val hpp:Double,val channel:String,val payment:String,val paid:Boolean=true,val status:String="OK")
@Entity data class StockMove(@PrimaryKey(autoGenerate=true) val id:Long=0,val ts:Long,val ingredientId:Long,val delta:Double,val type:String,val value:Double=0.0,val ref:Long=0,val note:String="")
@Entity data class CashTx(@PrimaryKey(autoGenerate=true) val id:Long=0,val ts:Long,val type:String,val amount:Double,val note:String="",val ref:Long=0)

@Dao interface D{
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:Ingredient):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:Product):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:RecipeItem):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:Sale):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:StockMove):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(x:CashTx):Long
 @Query("SELECT * FROM Ingredient ORDER BY name") fun ings():Flow<List<Ingredient>>
 @Query("SELECT * FROM Ingredient WHERE id=:id") suspend fun ing(id:Long):Ingredient?
 @Query("SELECT * FROM Product WHERE id=:id") suspend fun prod(id:Long):Product?
 @Query("SELECT * FROM Product ORDER BY name") fun prods():Flow<List<Product>>
 @Query("SELECT * FROM RecipeItem") fun recipes():Flow<List<RecipeItem>>
 @Query("SELECT * FROM RecipeItem WHERE productId=:p") suspend fun recipe(p:Long):List<RecipeItem>
 @Query("DELETE FROM RecipeItem WHERE id=:id") suspend fun delRec(id:Long)
 @Query("DELETE FROM RecipeItem WHERE productId=:p") suspend fun delRecOf(p:Long)
 @Query("SELECT * FROM Sale ORDER BY ts DESC") fun sales():Flow<List<Sale>>
 @Query("SELECT * FROM Sale WHERE id=:id") suspend fun sale(id:Long):Sale?
 @Query("SELECT COUNT(*) FROM Sale WHERE productId=:p") suspend fun salesCount(p:Long):Int
 @Query("DELETE FROM Product WHERE id=:p") suspend fun delProd(p:Long)
 @Query("SELECT COUNT(*) FROM Product") suspend fun nProd():Int
 @Query("SELECT * FROM StockMove ORDER BY ts DESC") fun moves():Flow<List<StockMove>>
 @Query("SELECT * FROM StockMove WHERE ref=:r AND type='JUAL'") suspend fun movesOf(r:Long):List<StockMove>
 @Query("SELECT * FROM CashTx ORDER BY ts DESC") fun cash():Flow<List<CashTx>>
}
@Database(entities=[Ingredient::class,Product::class,RecipeItem::class,Sale::class,StockMove::class,CashTx::class],version=1,exportSchema=false)
abstract class DB:RoomDatabase(){abstract fun d():D}
