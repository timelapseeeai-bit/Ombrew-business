# Ombrew Business V3.0 – Navy Edition
## Instalasi (APK)
1. Pasang Android Studio (Koala atau lebih baru), pilih File > Open > folder OmbrewBusiness, tunggu Gradle sync.
2. Build > Build APK(s). Hasil: app/build/outputs/apk/debug/app-debug.apk. Salin ke HP, izinkan "install dari sumber tidak dikenal", lalu pasang.
   (Atau sambungkan HP dengan USB debugging lalu klik Run.)
3. Logo, ikon, dan foto menu sudah terpasang (res/drawable-nodpi). Foto produk lain: menu Produk > pilih produk > "Pasang / ganti foto".
## Panduan singkat
- Persediaan: isi bahan; Pembelian: masukkan harga beli (harga rata-rata dihitung otomatis). Harga bahan HARUS diisi lewat Pembelian agar HPP resep terhitung.
- Produk: pilih produk, atur harga, HPP resep atau manual. Resep awal Kopi Susu Gula Aren (8 botol) sudah ada, bisa diedit.
- Penjualan: pilih produk, jumlah, simpan. Stok berkurang otomatis. "Batalkan" membalik stok dan kas. Piutang: pakai "Terima piutang".
- Keuangan: catat Modal, Biaya, Prive. Laporan: pilih periode, unduh CSV.
- Pengaturan: PIN, target harian, backup/restore JSON (simpan file backup rutin di luar HP).
